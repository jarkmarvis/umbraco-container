﻿using Microsoft.AspNetCore.Mvc;
using Umbraco.Cms.Core.Models;
using Umbraco.Cms.Core.PropertyEditors.ValueConverters;
using Umbraco.Cms.Web.Common;

namespace HealthTechSolutions_Umbraco.Views.Components.Footer;

/// <summary>
/// FooterBadges view component takes in a list custom media type (FooterBadges) and applies styling
/// MAJ 07/27/2023
/// </summary>
[ViewComponent(Name = "FooterBadgesView")]
public class FooterBadgesViewViewComponent : ViewComponent
{
	private readonly UmbracoHelper _umbracoHelper;

	public FooterBadgesViewViewComponent(UmbracoHelper umbracoHelper)
	{
		_umbracoHelper = umbracoHelper;
	}

	/// <summary>
	/// 
	/// </summary>
	/// <param name="badges"></param>
	/// <returns></returns>
	public Task<IViewComponentResult> InvokeAsync(IEnumerable<MediaWithCrops> badges)
	{
		var contentItems = new List<FooterBadgeContent>();
		if (badges != null)
		{
			foreach (var badge in badges)
			{
				contentItems.Add(new FooterBadgeContent
				{
					CertBadgeTitle = badge.Content.Value<string>("CertBadgeTitle"),
					CertBadgeUrl = badge.Content.Value<Link>("CertBadgeUrl"),
					File = badge.Content.Value<ImageCropperValue>("UmbracoFile"),
					Height = badge.Content.Value<int>("UmbracoHeight"),
					Width = badge.Content.Value<int>("UmbracoWidth")
				});
			}
		}

		return Task.FromResult<IViewComponentResult>(badges != null ? View(badges) : View(404));
	}
}

internal sealed class FooterBadgeContent
{
	public string CertBadgeTitle { get; set; } = string.Empty;

	public Link? CertBadgeUrl { get; set; }

	public ImageCropperValue? File { get; set; }

	public int Height { get; set; }

	public int Width { get; set; }
}

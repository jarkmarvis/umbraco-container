﻿using HealthTechSolutions.ContentModels;
using Microsoft.AspNetCore.Mvc;

namespace HealthTechSolutions_Umbraco.Views.Components.Footer;

/// <summary>
/// Footer view component takes in the Site Footer Content Model
/// and returns the Site Footer View
/// This class is flexible based on what page is being displayed.
/// MAJ 07/26/2023
/// </summary>
[ViewComponent(Name = "FooterView")]
public class FooterViewComponent : ViewComponent
{
	/// <summary>
	/// Invokes the generation of the Site Footer View
	/// Template can be found here: Views\Shared\Components\FooterView\Default.cshtml
	/// </summary>
	/// <param name="siteFooter">SiteFooter Content Model</param>
	/// <returns>ViewComponent Result of the Site Footer</returns>
	public IViewComponentResult InvokeAsync(SiteFooter siteFooter)
	{
		//use var model = this.ViewData.Model to inject custom content for the given page into the footer

		return View(siteFooter);
	}
}

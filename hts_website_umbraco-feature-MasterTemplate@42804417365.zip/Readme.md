# HealthTech Solutions WebSite
Umbraco based website for HealthTech Solutions

## Getting Started
More information about Umbraco can be found at https://umbraco.com/ 

Addition resources can be found at [https://docs.umbraco.com/umbraco-cms/](https://docs.umbraco.com/umbraco-cms/ "(target|_blank)") 

Also check the Umbraco community forums at https://our.umbraco.com/forum/

## Local Development
### Prerequisites
	* Visual Studio 2017 or later
	* .Net Core 2.1 or later
	* SQL Server 2016 or later
	* Minumum 8GB Ram
	* SQL Database Management 
	* Administrative access to create a database
	* One of the following OSs:
		- Microsoft Windows 10 or 11
		- MacOS High Sierra 10.13
		- Linux (Ubuntu, Alpine, CentOS, Debian, Fedora, openSUSE and other major distributions)
	* One of the following .NET Tools or Editors:
		- Visual Studio Code with the IISExpress extension
		- Microsoft Visual Studio 2022 v17.4
		- JetBrains Rider version 2022.3 and higher
		- .NET Core CLI
	* .NET 7.0
	* SQL connection string (SQL Server)

### Development Notes
	Templates rely on the custom class App_Plugins/Helpers/ContentHelpers. The method GetPropertyFallback<T> takes in a property, 
	a content model, of IPublishedContent type, an alias name, and a IPublishedValueFallback. This was created to overcome a shortfall in 
	retrieving fallback values from custom content compositions. Umbraco treats custom compositions as elements, which do not support ancestor fallback.

### Database Setup

#### Prerequisites
	* SQL Server 2016 or later
	* Minumum 8GB Ram
	* SQL Administrative access to create a database

### Project	Setup
1. Clone this repository
2. Open the solution in Visual Studio
3. Add a secrets.json file to the HealthTechSolutions_Umbraco.cspro
	* Right click on the project and select Manage User Secrets. This will open a secrets.json file in the editor.
4. Open the appsettings.Development.json file and copy the "ConnectionString" section and paste it into the secrets.json file.
5. Open the appsettings.Development.json file and copy the "Umbraco" section and paste it into the secrets.json file.
6. Close both app settings documents and make the following updates in the secrets.json file.
7. Make sure the two sections are separated with a ',' comma.
8. Update the "umbracoDbDSN" value to match the connection string of your local db environment.
9. Update the "UnattendedUserName" "UnattendedUserEmail" and "UnattendedUserPassword" values.
	* These values are used for initial configuration of Umbraco.
	* You can use the default UserName, supply your HTS email and create any password here.
10. Save the secrets.json file.

Sample secrets.json file
````
{
	"ConnectionStrings": {
		"umbracoDbDSN": "Server=(localdb)\\MSSQLLocalDB;Database=HealthTechSolutions_Umbraco;Trusted_Connection=True;MultipleActiveResultSets=true"
	},
	"Umbraco": {
		"UnattendedUserName": "admin",
		"UnattendedUserEmail": "your email",
		"UnattendedUserPassword": "your password"
	}
}
````
#### Project Setup Notes: Thing to elaborate on for installation/deployment
	appsettings.Development.json
		Make sure the ModelsBuilder settings are updated with the following Key:Values
		ModelsNamespace : HealthTechSolutions.ContentModels 
			--This is the namespace that will be used for dynamic content model generation
		ModelsMode : default : SourceCodeAuto  
			--This controls when content models are generated, 
				--Use "SourceCodeAuto" for development
				--Use "SourceCodeManual" for production
		DebugLevel : default : 0
			--Change this settings in development only. Higher numbers increase the debug level for content models.
		AcceptUnsafeModelsDirectory : false
			--This should ALWAYS be false, it is a security risk to move content models outside the web root
	More information available here: https://docs.umbraco.com/umbraco-cms/reference/configuration/modelsbuildersettings

Sample "ModelsBuilder" section, goes under the Umbraco:CMS: section
````
"Umbraco": {
  "CMS": {
    "ModelsBuilder": {
        "ModelsMode": "SourceCodeAuto",
        "ModelsNamespace": "HealthTechSolutions.ContentModels",
        "FlagOutOfDateModels": false,
        "ModelsDirectory": "~/umbraco/models",
        "AcceptUnsafeModelsDirectory": false,
        "DebugLevel": 0
    }
  }
}
````

## Hosting
### Recommendation
For the best experience the hosting environment should have the following:

	* Windows Server 2019 and higher
	* IIS 10 and higher
	* SQL Server 2019 and higher
	* .NET 7.0
	* Ability to set file permissions to include create/read/write (or better) for the user that "owns" the Application Pool for your site (NETWORK SERVICE, typically)

## Dependencies

### Packages
	The Dashboard
	Usync
	Usync Core
	Contentment - Add social links and other media and data types.
	X Bootstrap 5.x (Latest)
	Bootstrap.sass 5.x (Latest) 

### AddOns
	Bootstrap Icons
	
	Pooper.js
	RFS - Responsive Font Size https://github.com/twbs/rfs/tree/v9.0.3#usage

### Custom
	FooterViewViewComponent - Adds customizability to a site footer

### Other notes and useful documentation

https://docs.umbraco.com/umbraco-cms/fundamentals/backoffice/property-editors/built-in-umbraco-property-editors/image-cropper

#### Setting up a new media type for cert images, employee profiles etc to be used in razor pages.
https://docs.umbraco.com/umbraco-cms/fundamentals/data/creating-media/

#### The object printout for the custom content item
Content, Umbraco.Cms.Web.Common.PublishedModels.LinkableImage
LocalCrops, /media/na0ddufs/comptia_cysa_2bce.png
ContentType, Umbraco.Cms.Core.Models.PublishedContent.PublishedContentType
Key, b5fd0883-ccee-46cb-bb0d-f45840341f9f
Id, 1086
Name, CompTiaCert
UrlSegment,
SortOrder, 0
Level, 2
Path, -1,1085,1086
TemplateId, -1
CreatorId, -1
CreateDate, 7/26/2023 9:03:05 PM
WriterId, -1
UpdateDate, 7/26/2023 9:03:05 PM
Cultures, System.Collections.Generic.Dictionary`2[System.String,Umbraco.Cms.Core.Models.PublishedContent.PublishedCultureInfo]
ItemType, Media
Parent, Umbraco.Cms.Web.Common.PublishedModels.CertificationImages
Children, System.Linq.Enumerable+WhereEnumerableIterator`1[Umbraco.Cms.Core.Models.PublishedContent.IPublishedContent]
ChildrenForAllCultures, Umbraco.Cms.Infrastructure.PublishedCache.PublishedContent+<get_ChildrenForAllCultures>d__52
Properties, Umbraco.Cms.Core.Models.PublishedContent.IPublishedProperty[]

﻿using Umbraco.Cms.Infrastructure.Scoping;
using Umbraco.Cms.Web.BackOffice.Controllers;
using Umbraco.Cms.Web.Common.Attributes;

namespace HealthTechSolutions_Umbraco.App_Code;

[PluginController("My")]
public class PersonApiController : UmbracoAuthorizedJsonController
{
	private readonly IScopeProvider scopeProvider;

	public PersonApiController(IScopeProvider scopeProvider)
	{
		this.scopeProvider = scopeProvider;
	}

	public IEnumerable<Person> GetAll()
	{
		using (var scope = scopeProvider.CreateScope(autoComplete: true))
		{
			// build a query to select everything the people table
			var sql = scope.SqlContext.Sql().Select("*").From("people");

			// fetch data from the database with the query and map to the Person class
			return scope.Database.Fetch<Person>(sql);
		}
	}
}

public class Person
{
	public int Id { get; set; }
	public string Name { get; set; }
	public string Town { get; set; }
	public string Country { get; set; }
}

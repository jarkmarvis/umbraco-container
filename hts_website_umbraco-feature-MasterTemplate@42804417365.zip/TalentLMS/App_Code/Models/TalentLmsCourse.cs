﻿using Umbraco.Cms.Core.Routing;

namespace HealthTechSolutions_Umbraco.Controllers.Models;

public class TalentLmsCourse
{
	/// <summary>
	/// Unique identifier fr the configuration
	/// </summary>
	public int Id { get; set; }

	/// <summary>
	/// The course name
	/// </summary>
	public string? Name { get; set; }

	/// <summary>
	/// The course description 
	/// </summary>
	public string? Description { get; set; }
}

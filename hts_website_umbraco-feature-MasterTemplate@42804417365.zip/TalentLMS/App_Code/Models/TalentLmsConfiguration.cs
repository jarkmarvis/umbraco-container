﻿using Umbraco.Cms.Core.Routing;

namespace HealthTechSolutions_Umbraco.Controllers.Models;

public class TalentLmsConfiguration
{
	/// <summary>
	/// Unique identifier fr the configuration
	/// </summary>
	public int Id { get; set; }

	/// <summary>
	/// The site address to the TLMS instance
	/// </summary>
	public string? TlmsDomain { get; set; }

	/// <summary>
	/// The TalentLMS Api Key 
	/// </summary>
	public string? ApiKey { get; set; }
}

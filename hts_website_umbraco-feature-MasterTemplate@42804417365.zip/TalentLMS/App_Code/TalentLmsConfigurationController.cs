﻿using HealthTechSolutions_Umbraco.Controllers.Models;
using Umbraco.Cms.Infrastructure.Scoping;
using Umbraco.Cms.Web.BackOffice.Controllers;
using Umbraco.Cms.Web.Common.Attributes;

namespace HealthTechSolutions_Umbraco.Controllers;

[PluginController("TalentLms")]
public class TalentLmsConfigurationController : UmbracoAuthorizedJsonController
{
	private readonly IScopeProvider scopeProvider;

	public TalentLmsConfigurationController(IScopeProvider scopeProvider)
	{
		this.scopeProvider = scopeProvider;
	}

	public IEnumerable<TalentLmsConfiguration> GetAll()
	{
		using (var scope = scopeProvider.CreateScope(autoComplete: true))
		{
			// build a query to select everything the people table
			var sql = scope.SqlContext.Sql().Select("*").From("tlmsconfiguration");

			// fetch data from the database with the query and map to the Person class
			return scope.Database.Fetch<TalentLmsConfiguration>(sql);
		}
	}
}

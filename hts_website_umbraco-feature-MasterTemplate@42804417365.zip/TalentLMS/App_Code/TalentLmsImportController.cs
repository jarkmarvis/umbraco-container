﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Umbraco.Cms.Web.BackOffice.Controllers;
using Umbraco.Cms.Web.Common.Attributes;

namespace HealthTechSolutions_Umbraco.Controllers;

[PluginController("TalentLms")]
public class TalentLmsImportController : UmbracoAuthorizedJsonController
{
	public TalentLmsImportController()
	{
		var test = "";
	}
	// TODO add Talent LMS service
	// read config from tlms_configuration table
	// connect and get all courses save the data in tlms_courses
}

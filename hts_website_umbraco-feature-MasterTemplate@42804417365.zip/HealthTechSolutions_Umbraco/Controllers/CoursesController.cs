﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ViewEngines;
using Umbraco.Cms.Core.Web;
using Umbraco.Cms.Web.Common.Controllers;

namespace HealthTechSolutions_Umbraco.Controllers;
//TODO investigate custom controllers, server side code would be much more efficient
public class CoursesController : RenderController
{
	public CoursesController(ILogger<RenderController> logger, ICompositeViewEngine compositeViewEngine, IUmbracoContextAccessor umbracoContextAccessor)
		: base(logger, compositeViewEngine, umbracoContextAccessor)
	{
	}
	public override IActionResult Index()
	{
		//Default page
		return CurrentTemplate(CurrentPage);
	}

	// TODO implement frontend Course Search
	public IActionResult CourseSearch()
	{
		return CurrentTemplate(CurrentPage);
	}
}

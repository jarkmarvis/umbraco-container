﻿using Microsoft.AspNetCore.Mvc;

namespace HealthTechSolutions_Umbraco.Models;

public class PagedList<T> : List<T>
{
	/// <summary>
	/// Constructor: Generate pagination for any list type model
	/// </summary>
	/// <param name="currentPage"></param>
	/// <param name="totalItems"></param>
	/// <param name="pageNumber"></param>
	/// <param name="pageSize"></param>
	public PagedList(IEnumerable<T> currentPage, int totalItems, int pageNumber, int pageSize)
	{
		Page = pageNumber;
		PageSize = pageSize;
		ItemCount = totalItems;
		AddRange(currentPage);
	}

	/// <summary>
	/// The current page number
	/// </summary>
	[BindProperty(SupportsGet = true)]
	public int Page { get; set; } = 1;

	/// <summary>
	/// The count of all items
	/// </summary>
	public int ItemCount { get; set; }

	/// <summary>
	/// Number of items per page
	/// </summary>
	public int PageSize { get; set; } = 10;

	/// <summary>
	/// Number of pages
	/// </summary>
	public int TotalPages => (ItemCount + PageSize - 1) / PageSize; //(int)Math.Ceiling(TotalItems / (double)PageSize);

	/// <summary>
	/// Creates a page of results from the source
	/// </summary>
	/// <param name="source">IEnumerable generic source</param>
	/// <param name="pageNumber">Current page number</param>
	/// <param name="pageSize">The number of items to take from</param>
	/// <returns>Result page of items</returns>
	public static PagedList<T> Create(IEnumerable<T> source, int pageNumber, int pageSize)
	{
		int totalItems = source.Count();
		var pageOfItems = source.Skip((pageSize * pageNumber) - pageSize > 0 ? (pageSize * pageNumber) - pageSize : 0).Take(pageSize);

		return new PagedList<T>(pageOfItems, totalItems, pageNumber, pageSize);
	}
}

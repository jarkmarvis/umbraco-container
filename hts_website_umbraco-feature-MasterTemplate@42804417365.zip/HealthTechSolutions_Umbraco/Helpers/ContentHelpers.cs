﻿using Umbraco.Cms.Core.Models.PublishedContent;

namespace HealthTechSolutions_Umbraco.Helpers;

public class ContentHelpers
{
	/// <summary>
	/// Attempts to get value of a property from the content ancestors.
	/// </summary>
	/// <typeparam name="T">Type inherited from property</typeparam>
	/// <param name="property">Value Type T</param>
	/// <param name="name">Name of the property, used as alias for lookup</param>
	/// <param name="content">Model of the Razor page</param>
	/// <param name="fallback">Fallback value interface</param>
	/// <returns>object of type T</returns>
	/// <exception cref="ArgumentException"></exception>
	/// <exception cref="ArgumentNullException"></exception>
	public static T? GetPropertyWithFallback<T>(T property, string name, IPublishedContent content, IPublishedValueFallback fallback)
	{

		return property != null
			? property
			: string.IsNullOrEmpty(name)
			? throw new ArgumentException($"'{nameof(name)}' cannot be null or empty.", nameof(name))
			: content is null
			? throw new ArgumentNullException(nameof(content))
			: fallback is null
			? throw new ArgumentNullException(nameof(fallback))
			: content.Value<T>(fallback, name, fallback: Fallback.ToAncestors);
	}
}
